import React from 'react';
import DesempenoEscolar from './DesempenoEscolar';

function App() {
  return (
    <div className="App">
      <DesempenoEscolar />
    </div>
  );
}

export default App;
